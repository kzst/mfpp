## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----warning=FALSE,message=FALSE----------------------------------------------
library(mfpp) # Matrix-based Flexible Project Planning
library(knitr) # Apply graphical elements

## ----warning=FALSE,message=FALSE,fig.height=5,fig.width=7---------------------
# Calculatation of EST, EFT, LST and LFT times of activity of a project

# Define a 3 by 3 upper triangular binary matrix (DSM) of logic domain (LD) of a project.

# Specify the precendence of three tasks
# Diagonal values indicates the priority of tasks
# 1=the task is mandatory
LD<-rbind(c(1,0,1), c(0,1,0), c(0,0,1))

# Define a 3 by 1 vector of time durations of a project, where the durations are 3,4,5 respectively.
TD<-c(3,4,5) 

# Calculate project duration (total project time, TPT)
TPT<-tpt(LD,TD) 

summary(TPT)

# Specify initial scheduled start time, where the delay is 1 for the .
SST <- c(1,1,0)

# Including scheduled starts and finishes.

TPT<-tpt(LD,TD,SST)

# Print schedule table
summary(TPT)

# Plot the scheduled Gantt chart
plot(TPT,sched="S")

## ----warning=FALSE,message=FALSE,fig.height=5,fig.width=7---------------------
# Specify seed
set.seed(101)
# Specify the cost demands
CD<-c(10,20,24)

cat("\nTotal Project Cost (TPC): ",tpc(LD,CD))


# Specify quality parameters
q<-runif(3)

# For fixed project plan the TPQ is the geometric mean of quality parameters

cat("\nTotal Project Quality (TPC): ",tpq(LD,LD,q)) 

# Calculate relative quality for the selected completion modes

QD2<-cbind(q,runif(3)) # Generate two completion modes

# Calculate relative quality considering the best choice

cat("\nRelative TPQ: ",tpq(LD,LD,q,QD2)) 


# Generate resource demands (RD)

RD<-round(cbind(runif(3,min = 0,max=5),runif(3,min=0,max=5)))

cat("\n\nTotal Project Resources (TPR)\n\n")

tpr(TPT$SST,LD,TD,RD)
 
## Plot resources for SST

tpr(TPT$SST,LD,TD,RD,res.graph = TRUE)


## ----warning=FALSE,message=FALSE,fig.height=5,results='hide',fig.width=7------

# Calculate (Pareto) optimal SST
RES<-paretores(LD,TD,RD)

# Plot resource graph
tpr(RES$SST,LD,TD,RD,res.graph = TRUE)

# Plot Gantt Chart
plot(tpt(LD,TD,RES$SST),sched = "S")

## ----warning=FALSE,message=FALSE,results='hide',fig.width=7,fig.height=5,retina=1----
PDM<-cbind(LD,TD,CD,q,RD)
class(PDM)<-"PDM_matrix"

summary(PDM,w=1,Rs=2)
plot(PDM,w=1,Rs=2)

## ----fig.width=7,fig.height=5,warning=FALSE,message=FALSE---------------------
# Generation of PDM matrix for flexible project planning MFPP package.

# Define number of modes, flexibility factor and connectivity factor of a project scenerio.
N=5;ff=0.30;cf=0

# Define maximum value of time domain, Cost domain and Resourcces domain of a project scenerio.
mTD=3;mCD=4;mRD=3

# Define number of modes, number of resources,
# number of possible extra tasks (nW), scale and quality domain of a project scenerio.

w=2;nR=2;nW=1
scale=1.6  

PDM<-generatepdm(N,ff,cf,mTD,mCD,mRD,w,nR,nW,scale,QD=TRUE,lst=TRUE)

summary(PDM) # Summary of PDM list

## ----warning=FALSE,message=FALSE,results='hide',fig.width=7,fig.height=5,retina=1----
plot(PDM) # Plot PDM structures

## ----warning=FALSE,message=FALSE----------------------------------------------
# Get most likely / most desired project structure list (PSM_list)
PSM_list<-get.structures(PDM,type = "most")$moststruct
summary(PSM_list)

## ----warning=FALSE,message=FALSE,results='hide'-------------------------------

# Get PSM matrix
# Drop excluded tasks, and their demands
PSM<-round(truncpdm(PSM_list$PDM))

w<-PSM_list$w # Get number of completion modes
Rs<-PSM_list$Rs # Get number of resurces

DSM<-PSM[,1:nrow(PSM)] # Get PSM matrix

# Get time demands (time domain, TD)
TD<-PSM[,paste("t",1:w,sep = "_")] 

# Get resource demands (resource domain, RD)
RD<-PSM[,tail(colnames(PSM),w*Rs)]

# Calculate optimal schedules for both completion modes

RES1<-paretores(DSM,TD[,1],RD[,1:Rs])
RES2<-paretores(DSM,TD[,2],RD[,(Rs+1):(2*Rs)])

## ----warning=FALSE,message=FALSE,fig.width=7,fig.height=5---------------------
plot(tpt(DSM,TD[,1],RES1$SST))
kable(tpr(RES1$SST,DSM,TD[,1],RD[,1:Rs],res.graph=TRUE))

## ----warning=FALSE,message=FALSE,fig.width=7,fig.height=5---------------------
plot(tpt(DSM,TD[,2],RES1$SST))
kable(tpr(RES1$SST,DSM,TD[,2],RD[,(Rs+1):(2*Rs)],res.graph=TRUE))

## ----warning=FALSE,message=FALSE----------------------------------------------
# Get the Boctor's simulation database 

# Boctor, F. F. (1993). 
# Heuristics for scheduling projects with resource restrictions and several resource-duration modes. 
# The International Journal of Production Research, 
# 31(11), 2547–2558, 
# https://doi.org/10.1080/00207549308956882.

data(Boctor)
Collection<-Boctor

summary(Collection)

## ----warning=FALSE,message=FALSE----------------------------------------------
I<-2 # I-th number of project

PDM_list<-Collection[[I]]$PDM_list
PDM<-PDM_list$PDM
w<-PDM_list$w
Rs<-PDM_list$Rs

summary(PDM_list)

## ----warning=FALSE,message=FALSE,results='hide',fig.width=7,fig.height=7------
plot(PDM_list)

## ----warning=FALSE,message=FALSE,results='hide',fig.width=7,fig.height=7------
PSM<-PDM_list$PDM
DSM<-PSM[,1:nrow(PSM)] # Get PSM matrix

# Get time demands (time domain, TD)
TD<-PSM[,paste("t",1:w,sep = "_")]

# Plot 1st completion mode, scheduled by EST
plot(tpt(DSM,TD[,1]))

# Plot 2nd completion mode, scheduled by EST
plot(tpt(DSM,TD[,2]))

# Plot 3rd completion mode, scheduled by EST
plot(tpt(DSM,TD[,3]))

# Plot 4th completion mode, scheduled by EST
plot(tpt(DSM,TD[,4]))

## ----warning=FALSE,message=FALSE,results='hide',fig.width=7,fig.height=7------
# Changes of demands followed by uniform distribution (default)
PSM1<-phase1(PSM,a=-0.2,b=0.4) 

# Changes of demands followed by beta distribution
PSM1b<-phase1(PSM,a=-0.2,b=0.4,pdftype="beta")

TD1<-PSM1[,paste("t",1:w,sep = "_")]
TD1b<-PSM1b[,paste("t",1:w,sep = "_")]

# Plot original 1st completion mode, scheduled by EST
plot(tpt(DSM,TD[,1]))

# Plot changed 1st completion mode, scheduled by EST
plot(tpt(DSM,TD1[,1]))

# Plot changed 1st completion mode, scheduled by EST
plot(tpt(DSM,TD1b[,1]))

## ----warning=FALSE,message=FALSE,results='hide',fig.width=7,fig.height=7------
# Changes of demands followed by uniform distribution (default)
# p: percentage of task selection
# s: maximal scale effect

PSM2<-phase2(PSM,p=0.2,s=10) 

TD2<-PSM2[,paste("t",1:w,sep = "_")]

# Plot original 1st completion mode, scheduled by EST
plot(tpt(DSM,TD[,1]))

# Plot changed 1st completion mode, scheduled by EST
plot(tpt(DSM,TD2[,1]))

## ----warning=FALSE,message=FALSE,results='hide',fig.width=7,fig.height=7------
# Changes of demands followed by uniform distribution (default)
# P: percentage of selection
# S: maximal change effect

PDMp<-phase3(PSM,0.1,0.5) # New possible dependencies
PDMn<-phase3(PSM,0.1,-0.5) # Completion and dependencies will be flexible

# Plot original structure
plot(PSM,type = "orig",main="Original structure")

# Plot PDM with more restrictions 
plot(PDMp,type = "orig",main="PDM with more dependencies")

# Plot PDM with less restrictions 
plot(PDMn,type = "orig",main="PDM with less restrictions")

